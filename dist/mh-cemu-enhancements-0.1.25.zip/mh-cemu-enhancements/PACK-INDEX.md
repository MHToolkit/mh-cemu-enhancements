# Pack Distribution Index / 插件发行索引

This file is generated deterministically from the catalog. 本文件由目录清单确定性生成。

Release layout / 发行布局: `packs/<platform>/<title>/<region-update>/<category-folder>/<pack>/`

Total / 总数: **57**; available / 可用: **54**; runtime-blocked / 运行时阻塞: **3**.

## `01-frame-rate` — 帧率相关 / Frame Rate

帧率锁定，以及非原生帧率下出现的行为差异修复。 / Frame-rate locks and fixes for behavior that changes at non-native frame rates.

Pack count / 插件数: **5** (available / 可用: 5; runtime-blocked / 运行时阻塞: 0).

### `mh3g-hd-jp-v96-60fps-camera-speed` — 60帧视角速度 / 60FPS Camera Speed

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/01-frame-rate/60fps-camera-speed-fix/manifest.json`
- **Summary / 摘要:** 中文：仅应在 60 FPS 运行时启用；按所选预设把普通视角基值 `0x40B` 和瞄准视角基值 `0x34B` 统一缩放到 40%..120%，默认预设为 70%，用来校正 60 FPS 下过快或不合手感的镜头转速。 状态：Runtime Experimental，默认关闭。 / English: Enable only while running at 60 FPS; the selected preset uniformly scales normal-camera base `0x40B` and aiming-camera base `0x34B` across 40%..120%, defaulting to 70% to correct camera rotation that feels too fast or unsuitable at 60 FPS. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：仅应在 60 FPS 运行时启用；按所选预设把普通视角基值 `0x40B` 和瞄准视角基值 `0x34B` 统一缩放到 40%..120%，默认预设为 70%，用来校正 60 FPS 下过快或不合手感的镜头转速。边界：补丁本身不检测当前 FPS，在 30/44 FPS 启用也会缩放并造成错误手感；它不修改角色移动、瞄准输入死区、全局控制器灵敏度或其他镜头路径。修改预设后必须完整重载标题，100% 表示保留原始数值而不是 30 FPS 补偿。验证：固定手柄、灵敏度和镜头起点，只启用本项，在 60 FPS 下分别用 100%、默认 70% 和另一个预设测量普通/瞄准镜头完成同角度旋转的时间，并确认菜单、锁定和零输入路径无异常。来源/状态：JP v96 两个固定视角载入点的 codecave 缩放，已通过 RPX 前像、原生 CR 保留和 PPCAssembler 校验；默认关闭；Runtime Experimental / Gameplay Pending。 / English: Effect: enable only while running at 60 FPS; the selected preset uniformly scales normal-camera base `0x40B` and aiming-camera base `0x34B` across 40%..120%, defaulting to 70% to correct camera rotation that feels too fast or unsuitable at 60 FPS. Scope: the patch does not detect the current FPS, so enabling it at 30/44 FPS also scales the camera and produces incorrect feel; it does not change hunter movement, aiming dead zones, global controller sensitivity, or unrelated camera paths. Fully reload the title after changing presets, and 100% means native values rather than a 30-FPS compensation. Verify: keep controller, sensitivity, and camera start fixed, enable only this pack at 60 FPS, and measure equal-angle rotations for normal and aiming views at 100%, default 70%, and one additional preset; also confirm menus, lock-on, and zero-input paths remain normal. Source/status: codecave scaling at two fixed JP-v96 camera-load sites, with RPX preimages, native CR preservation, and PPCAssembler checks passed; Disabled by default; Runtime Experimental / Gameplay Pending.

### `mh3g-hd-jp-v96-60fps-hammer-golf-swing-fix` — 60帧锤子正本垒修复 / 60FPS Hammer Golf Swing Fix

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/01-frame-rate/60fps-hammer-golf-swing-fix/manifest.json`
- **Summary / 摘要:** 中文：仅应在 60 FPS 运行时启用；把锤子旋转攻击的单帧角度步进翻倍，并准确重放被 Hook 跨过的圈数递减指令，目标是恢复 30 FPS 下可正常派生的“正本垒/高尔夫挥击”时机。 状态：Runtime Experimental，默认关闭。 / English: Enable only while running at 60 FPS; doubles the hammer spin attack's per-frame angle step and exactly replays the loop-count decrement skipped by the hook, aiming to restore the golf-swing/home-run follow-up timing available at 30 FPS. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：仅应在 60 FPS 运行时启用；把锤子旋转攻击的单帧角度步进翻倍，并准确重放被 Hook 跨过的圈数递减指令，目标是恢复 30 FPS 下可正常派生的“正本垒/高尔夫挥击”时机。边界：补丁只覆盖旋转攻击进度点 `0x0287F43C`，不修改蓄力等级、伤害、耐力、其他锤子动作或其他武器；在 30/44 FPS 启用会过度修正，且不同输入时机仍需实机覆盖。验证：固定锤子、任务、地形与输入节奏，在 30 FPS 原生基线、60 FPS 关闭、60 FPS 启用三种条件下多次执行旋转攻击并尝试相同按键时机的正本垒派生，记录成功率、旋转圈数和后续控制恢复。来源/状态：JP v96 单点 Hook 加 codecave，原生 `fadds` 与 `subi` 各重放一次，已通过前像、控制流边界和 PPCAssembler 校验；默认关闭；Runtime Experimental / Gameplay Pending。 / English: Effect: enable only while running at 60 FPS; doubles the hammer spin attack's per-frame angle step and exactly replays the loop-count decrement skipped by the hook, aiming to restore the golf-swing/home-run follow-up timing available at 30 FPS. Scope: it covers only spin-progress site `0x0287F43C` and changes no charge level, damage, stamina, other hammer action, or other weapon; enabling it at 30/44 FPS overcorrects, and different input timings still need gameplay coverage. Verify: keep hammer, quest, terrain, and input rhythm fixed, repeatedly perform the spin and attempt the same golf-swing input timing under native 30-FPS baseline, 60 FPS with the pack off, and 60 FPS with it on; record success rate, spin count, and control recovery. Source/status: one JP-v96 hook plus codecave that replays the native `fadds` and `subi` exactly once, with preimage, control-flow-boundary, and PPCAssembler checks passed; Disabled by default; Runtime Experimental / Gameplay Pending.

### `mh3g-hd-jp-v96-60fps-knockback-distance` — 60帧风压吹飞距离修复 / 60FPS Knockback Distance

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/01-frame-rate/60fps-knockback-distance-fix/manifest.json`
- **Summary / 摘要:** 中文：仅应在 60 FPS 运行时启用；把普通风压吹飞使用的静态浮点常量由 `-18.0` 调整为 `-9.0`，目标是抵消 60 FPS 下按帧积分造成的双倍位移，使落点接近 30 FPS 基线。 状态：Runtime Experimental，默认关闭。 / English: Enable only while running at 60 FPS; changes the static float used by ordinary wind-pressure launch from `-18.0` to `-9.0`, aiming to cancel frame-integrated double travel at 60 FPS so the landing point approaches the 30-FPS baseline. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：仅应在 60 FPS 运行时启用；把普通风压吹飞使用的静态浮点常量由 `-18.0` 调整为 `-9.0`，目标是抵消 60 FPS 下按帧积分造成的双倍位移，使落点接近 30 FPS 基线。边界：补丁本身不检测当前 FPS，在 30/44 FPS 启用会把原生位移减半；它只覆盖引用该常量的普通风压吹飞，特殊怪物、脚本事件、其他击飞、受身或伤害位移可能走不同路径。验证：固定猎人位置、地形、怪物/风压来源和朝向，在 30 FPS 基线、60 FPS 关闭、60 FPS 启用三种条件下各重复至少三次，以场景标记测量起点到落点距离并比较中位数，同时确认受身和输入恢复正常。来源/状态：JP v96 文件映射数据字 `0x1007E110` 从 `0xC1900000` 改为 `0xC1100000`，代码路径保持原样，已通过数据前像与 PPCAssembler 校验；默认关闭；Runtime Experimental / Gameplay Pending。 / English: Effect: enable only while running at 60 FPS; changes the static float used by ordinary wind-pressure launch from `-18.0` to `-9.0`, aiming to cancel frame-integrated double travel at 60 FPS so the landing point approaches the 30-FPS baseline. Scope: the patch does not detect current FPS, so enabling it at 30/44 FPS halves native travel; it covers only ordinary wind-pressure launch callers of this constant, while special monsters, scripts, other launches, recovery, or damage displacement may use different paths. Verify: keep hunter start, terrain, monster/wind source, and facing fixed; repeat at least three times each under 30-FPS baseline, 60 FPS off, and 60 FPS on, measure start-to-landing distance against scene markers, compare medians, and confirm recovery/input remain normal. Source/status: JP-v96 file-backed data word `0x1007E110` changed from `0xC1900000` to `0xC1100000` with code paths untouched, and data-preimage plus PPCAssembler checks passed; Disabled by default; Runtime Experimental / Gameplay Pending.

### `mh3g-hd-jp-v96-fps-lock-30` — MH3G HD JP v96 - Lock 30 FPS

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/01-frame-rate/fps-lock-30/manifest.json`
- **Summary / 摘要:** 中文：通过本标题专属 Graphic Pack 控制项把 Cemu 的 VSync 目标设为 30 FPS，使 MH3G HD JP v96 以 30 帧上限运行；它不改 RPX 指令，也不改 Cemu 全局配置。 状态：Runtime Experimental，默认关闭。 / English: Uses a title-scoped Graphic Pack control to set Cemu's VSync target to 30 FPS for MH3G HD JP v96; it patches no RPX instruction and changes no global Cemu setting. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：通过本标题专属 Graphic Pack 控制项把 Cemu 的 VSync 目标设为 30 FPS，使 MH3G HD JP v96 以 30 帧上限运行；它不改 RPX 指令，也不改 Cemu 全局配置。边界：本项只设定帧率目标，不修复帧率相关的动作、物理、镜头或音频逻辑；不得与 44 FPS 同时启用，三个仅供 60 FPS 使用的行为修复也应保持关闭。既有实测观察到帧率或帧节奏不稳定，因此不能把计数器短暂显示 30 当作稳定通过。验证：只启用本项并完整重载标题，在村庄、酒场和至少一场任务中分别记录 FPS、帧时间、镜头、输入、音频及战斗节奏，持续观察而不是只截取瞬时数值。来源/状态：仓库原生 Cemu `vsyncFrequency = 30` 控制包；默认关闭；Runtime Experimental，稳定性待复测。 / English: Effect: uses a title-scoped Graphic Pack control to set Cemu's VSync target to 30 FPS for MH3G HD JP v96; it patches no RPX instruction and changes no global Cemu setting. Scope: this pack sets only the frame-rate target and does not repair frame-dependent animation, physics, camera, or audio logic; never combine it with 44 FPS, and leave all three 60-FPS-only behavior fixes disabled. Existing gameplay testing observed unstable frame rate or pacing, so a momentary 30 counter is not a stability pass. Verify: enable only this pack, fully reload the title, and record FPS, frame time, camera, input, audio, and combat pacing in the village, lobby, and at least one quest over sustained runs rather than a single counter snapshot. Source/status: repository-native Cemu `vsyncFrequency = 30` control pack; Disabled by default; Runtime Experimental pending a stability retest.

### `mh3g-hd-jp-v96-fps-lock-44` — MH3G HD JP v96 - Lock 44 FPS (3DS Conversion)

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/01-frame-rate/fps-lock-44/manifest.json`
- **Summary / 摘要:** 中文：通过本标题专属 Graphic Pack 控制项把 Cemu 的 VSync 目标设为 44 FPS，复现活动 3DS 金手指中两条重复“44 帧”条目的帧率语义；它不改 RPX 指令或 Cemu 全局配置。 状态：Runtime Experimental，默认关闭。 / English: Uses a title-scoped Graphic Pack control to set Cemu's VSync target to 44 FPS, reproducing the frame-rate semantic of the two duplicate active 3DS “44 FPS” entries; it patches no RPX instruction and changes no global Cemu setting. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：通过本标题专属 Graphic Pack 控制项把 Cemu 的 VSync 目标设为 44 FPS，复现活动 3DS 金手指中两条重复“44 帧”条目的帧率语义；它不改 RPX 指令或 Cemu 全局配置。边界：本项只改变帧率目标，不包含动画、物理、镜头、音频或水下位移补偿；不要与 30 FPS 同时启用，三个按 60 FPS 标定的行为修复也不适用于 44 FPS。验证：只启用本项并完整重载标题，确认持续帧率目标接近 44，再在村庄、酒场、水下移动和至少一场完整任务中对照镜头、输入、音频、战斗速度及帧时间稳定性。来源/状态：由 3DS 源条目 #71 与 #73 的重复 44 FPS 语义转换为 Cemu `vsyncFrequency = 44`；默认关闭；Runtime Experimental，需实机稳定性验证。 / English: Effect: uses a title-scoped Graphic Pack control to set Cemu's VSync target to 44 FPS, reproducing the frame-rate semantic of the two duplicate active 3DS “44 FPS” entries; it patches no RPX instruction and changes no global Cemu setting. Scope: Do not enable together with 30 FPS. This pack changes only the frame-rate target and includes no animation, physics, camera, audio, or underwater-travel compensation; the three fixes calibrated specifically for 60 FPS do not apply at 44 FPS. Verify: enable only this pack, fully reload the title, confirm a sustained target near 44, then compare camera, input, audio, combat speed, and frame-time stability in the village, lobby, underwater travel, and at least one complete quest. Source/status: converts the duplicate 44-FPS semantics of 3DS source entries #71 and #73 into Cemu `vsyncFrequency = 44`; Disabled by default; Runtime Experimental and requires gameplay stability verification.

## `02-speed-and-actions` — 加速与动作 / Speed and Actions

移动、采集、设置、进食及其他动作速度调整。 / Movement, gathering, placement, eating, and other action-speed changes.

Pack count / 插件数: **6** (available / 可用: 6; runtime-blocked / 运行时阻塞: 0).

### `mh3g-hd-jp-v96-static-13-underwater-speed-x2` — 水下速度 2 倍 / Underwater Speed ×2

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/02-speed-and-actions/static-13-underwater-speed-x2/manifest.json`
- **Summary / 摘要:** 中文：把水下普通游泳及已覆盖动作状态的动作速率和最终坐标位移提高到约 2 倍；0.1.22 已补齐普通游泳状态 9 的两条最终积分，2026-08-07 本机实测已确认不再只是动画变快，实际移动距离也明显翻倍。 状态：Runtime Experimental，默认关闭。 / English: Raises action rate and final coordinate travel for ordinary swimming and the covered underwater action states to about 2x; 0.1.22 added both state-9 final integrations, and local gameplay on 2026-08-07 confirmed clearly doubled physical travel rather than animation-only speedup. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：把水下普通游泳及已覆盖动作状态的动作速率和最终坐标位移提高到约 2 倍；0.1.22 已补齐普通游泳状态 9 的两条最终积分，2026-08-07 本机实测已确认不再只是动画变快，实际移动距离也明显翻倍。边界：原 3DS 项没有修改普通游泳的最终位移积分，本包包含三条面向 Wii U 的窄范围适配；碰撞、转向、上浮/下潜、冲刺与闪避仍需独立复测，皮皮鸟复测尚待回报。验证：只启用本项并关闭 #65，固定 FPS、武器、满幅摇杆、镜头、动作与起终点，对同一路线计时，基线和启用后各至少三次并比较中位数。来源/状态：由 3DS 静态 ARM #13 转换并按 Wii U 位移路径修正；默认关闭；Runtime Experimental。 / English: Effect: raises action rate and final coordinate travel for ordinary swimming and the covered underwater action states to about 2x; 0.1.22 added both state-9 final integrations, and local gameplay on 2026-08-07 confirmed clearly doubled physical travel rather than animation-only speedup. Scope: the original 3DS entry never patched ordinary-swim final integration, so this pack includes three narrow Wii U adaptations; collision, turning, ascent/descent, dashing, and evasion still need independent coverage, and Pipi's retest is pending. Verify: enable only this pack, disable #65, keep FPS, weapon, full-stick input, camera, action, and endpoints fixed, time the same underwater route at least three times per mode, and compare medians. Source/status: converted from 3DS static ARM cheat #13 with Wii U travel-path corrections; Disabled by default; Runtime Experimental.

### `mh3g-hd-jp-v96-static-36-speed-eating-plus-2` — 速食者 +2 / Speed Eating +2

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/02-speed-and-actions/static-36-speed-eating-plus-2/manifest.json`
- **Summary / 摘要:** 中文：强制发动速食者 +2，明显缩短肉、药、饮料等受支持消耗品的入口与吞咽动画。 状态：Runtime Experimental，默认关闭。 / English: Forces Speed Eating +2, substantially shortening the use/swallow animation for supported meat, medicine, and drink items. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动速食者 +2，明显缩短肉、药、饮料等受支持消耗品的入口与吞咽动画。边界：不会加快采集、剥取、砥石、放置或收刀，也不会提高道具回复量。验证：固定同一种药和同一种肉，从按下使用到恢复可操作分别计时。来源/状态：由 3DS 静态 ARM #36 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Speed Eating +2, substantially shortening the use/swallow animation for supported meat, medicine, and drink items. Scope: it does not speed gathering, carving, whetstones, placement, or sheathing, and does not increase item potency. Verify: time from use-button press to regained control for the same medicine and the same meat with the pack off and on. Source/status: converted from 3DS static ARM cheat #36; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-53-speed-sharpening` — 砥石高速化 / Speed Sharpening

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/02-speed-and-actions/static-53-speed-sharpening/manifest.json`
- **Summary / 摘要:** 中文：强制发动砥石使用高速化，减少磨刀所需的重复动作并更快恢复操作。 状态：Runtime Experimental，默认关闭。 / English: Forces Speed Sharpening, reducing repeated whetstone motions and returning control sooner. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动砥石使用高速化，减少磨刀所需的重复动作并更快恢复操作。边界：不改变一次磨刀恢复的斩味量，也不阻止之后继续掉斩味（#5 才是锋利度不减）。验证：让同一武器掉到相同斩味后使用同一种砥石，计时到恢复可操作。来源/状态：由 3DS 静态 ARM #53 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Speed Sharpening, reducing repeated whetstone motions and returning control sooner. Scope: it does not change how much sharpness one whetstone restores or prevent later sharpness loss (#5 does that). Verify: lower the same weapon to the same sharpness, use the same whetstone, and time until control returns. Source/status: converted from 3DS static ARM cheat #53; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-59-faster-carve-gather` — 剥取、采集动作与获取加快 / Faster Carving, Gathering, and Acquisition

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/02-speed-and-actions/static-59-faster-carve-gather/manifest.json`
- **Summary / 摘要:** 中文：直接把共享剥取/采集动作倍率从 1.3 提到 2.0，并把获取结算倍率从 1.1 提到 1.5，使剥取、采集和拾取流程整体更快。 状态：Runtime Experimental，默认关闭。 / English: Directly changes the shared carve/gather action multiplier from 1.3 to 2.0 and acquisition multiplier from 1.1 to 1.5, speeding carving, gathering, and pickup flow. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：直接把共享剥取/采集动作倍率从 1.3 提到 2.0，并把获取结算倍率从 1.1 提到 1.5，使剥取、采集和拾取流程整体更快。边界：它改的是数值倍率，不增加采集次数或物品数量；与 #60 覆盖同类流程并会掩盖 #60 差异，少数动作可能出现动画与结算不同步。验证：只启用本项，在同一尸体和同一采集点分别计时完整循环。来源/状态：由 3DS 静态 ARM #59 精确转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: directly changes the shared carve/gather action multiplier from 1.3 to 2.0 and acquisition multiplier from 1.1 to 1.5, speeding carving, gathering, and pickup flow. Scope: it changes timing rather than gather count or item quantity; it overlaps and can mask #60, and a few actions may show animation/settlement desynchronization. Verify: enable only this pack and time complete cycles on the same carcass and the same gathering node. Source/status: exact conversion of 3DS static ARM cheat #59; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-60-fast-gathering` — 高速收集 / Fast Gathering

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/02-speed-and-actions/static-60-fast-gathering/manifest.json`
- **Summary / 摘要:** 中文：强制发动原生高速收集/Speed Gatherer，缩短受支持的采集、挖矿、捕虫和剥取循环动画。 状态：Runtime Experimental，默认关闭。 / English: Forces native Speed Gatherer, shortening supported gathering, mining, bug-catching, and carving animation cycles. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动原生高速收集/Speed Gatherer，缩短受支持的采集、挖矿、捕虫和剥取循环动画。边界：不会提高节点次数或每次获得数量；#59 的直接倍率和 #65 的广域技能查询都会掩盖本项差异。验证：只启用本项，关闭 #59 并关闭 #65，对同一采集点从首次交互到完整循环结束计时。来源/状态：由 3DS 静态 ARM #60 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces native Speed Gatherer, shortening supported gathering, mining, bug-catching, and carving animation cycles. Scope: it does not increase node uses or yield per action; #59's direct multipliers and #65's broad skill query can both mask the difference. Verify: enable only this pack, disable #59 and disable #65, then time a full cycle at the same gathering point from first interaction to completion. Source/status: converted from 3DS static ARM cheat #60; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-61-fast-placement` — 高速设置 / Fast Placement

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/02-speed-and-actions/static-61-fast-placement/manifest.json`
- **Summary / 摘要:** 中文：强制发动高速设置/Trap Master，缩短落穴、麻痹陷阱和桶爆弹等受支持物品的放置动作，并把陷阱相关调和成功率提高到 100%。 状态：Runtime Experimental，默认关闭。 / English: Forces Speed Setup/Trap Master, shortening placement of supported Pitfall/Shock Traps and Barrel Bombs while raising trap-related combination success to 100%. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动高速设置/Trap Master，缩短落穴、麻痹陷阱和桶爆弹等受支持物品的放置动作，并把陷阱相关调和成功率提高到 100%。边界：不会提高桶爆弹伤害、延长陷阱时间或让无效目标中陷阱；其他任务放置物是否共享路径需逐项确认。验证：分别计时同一陷阱和同一桶爆弹从按键到恢复操作，并测试低成功率陷阱调和。来源/状态：由 3DS 静态 ARM #61 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Speed Setup/Trap Master, shortening placement of supported Pitfall/Shock Traps and Barrel Bombs while raising trap-related combination success to 100%. Scope: it does not increase bomb damage, extend trap duration, or make trap-immune targets vulnerable; other quest placeables need item-by-item coverage. Verify: time the same trap and barrel bomb from button press to control recovery, then test a normally fallible trap combination. Source/status: converted from 3DS static ARM cheat #61; Disabled by default; Runtime Experimental and requires gameplay verification.

## `03-skills-and-immunities` — 技能与免疫 / Skills and Immunities

猎人或猫饭技能、抗性以及异常状态免疫。 / Hunter or meal skills, resistances, and status immunities.

Pack count / 插件数: **21** (available / 可用: 21; runtime-blocked / 运行时阻塞: 0).

### `mh3g-hd-jp-v96-custom-felyne-food-skills` — 猫饭技能自定义 / Custom Felyne Food Skills

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/custom-felyne-food-skills/manifest.json`
- **Summary / 摘要:** 中文：为三个猫饭技能槽分别提供 `00..41` 的完整双语选择，并在随机生成器返回后覆盖原生临时槽 `r31 + 0x68/0x6A/0x6C`，再由游戏原生循环同步用餐完成界面和任务运行状态；默认组合为 `06/36/00`。 状态：Runtime Experimental，默认关闭。 / English: Exposes complete bilingual `00..41` selectors for all three Felyne-food skill slots, overwrites native temporary slots `r31 + 0x68/0x6A/0x6C` after random generation, and lets the native loop mirror them into the completed-meal UI and quest runtime state; the in-pack default is `06/36/00`. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：为三个猫饭技能槽分别提供 `00..41` 的完整双语选择，并在随机生成器返回后覆盖原生临时槽 `r31 + 0x68/0x6A/0x6C`，再由游戏原生循环同步用餐完成界面和任务运行状态；默认组合为 `06/36/00`。边界：修改预设后必须完整重载标题并重新吃饭，已经完成的猫饭不会被追溯修改；餐前预览仍可能显示随机技能，游戏原生互斥或非法组合也可能只保留其中一项，已知 `41 + 1E` 不能共存。验证：只启用本项，选择容易辨认且彼此兼容的三个技能，完整重载标题、重新吃饭，并同时核对用餐完成列表与进入任务后的实际效果；再用 `41` 等显著技能单独复测，不能只看餐前预览。本机已有选定组合生效反馈，但尚未穷举全部 66 个 ID、三槽排列和互斥组合。来源/状态：由群友提供的 3DS/Gateway“猫饭自定义 v1.2”语义映射到 JP v96 原生用餐结算函数；默认关闭；Runtime Experimental，核心选择已有本机反馈但完整覆盖仍待验证。 / English: Effect: exposes complete bilingual `00..41` selectors for all three Felyne-food skill slots, overwrites native temporary slots `r31 + 0x68/0x6A/0x6C` after random generation, and lets the native loop mirror them into the completed-meal UI and quest runtime state; the in-pack default is `06/36/00`. Scope: after changing a preset, fully reload the title and eat again because an already completed meal is not retroactively changed; the pre-meal preview may remain random, and native mutually exclusive or invalid combinations may retain only one skill, with `41 + 1E` known to be incompatible. Verify: enable only this pack, choose three easily observable compatible skills, fully reload, eat again, and check both the completed-meal list and actual quest effects; then retest a conspicuous skill such as `41` by itself rather than relying on the pre-meal preview. Local testing has observed selected combinations taking effect, but all 66 IDs, three-slot permutations, and incompatibilities are not exhaustively covered. Source/status: maps the community-supplied 3DS/Gateway “Felyne Food Custom v1.2” semantic to the native JP-v96 meal finalizer; Disabled by default; Runtime Experimental with core local feedback but incomplete coverage.

### `mh3g-hd-jp-v96-static-11-awakening` — 里属性觉醒 / Awakening

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-11-awakening/manifest.json`
- **Summary / 摘要:** 中文：强制发动“觉醒”，解放武器原本灰显或隐藏的元素/异常属性，使该潜在属性参与面板与攻击结算。 状态：Runtime Experimental，默认关闭。 / English: Forces Awaken, releasing a weapon's grayed-out or latent element/status so it participates in the status screen and attack resolution. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动“觉醒”，解放武器原本灰显或隐藏的元素/异常属性，使该潜在属性参与面板与攻击结算。边界：没有隐藏属性的武器不会凭空获得属性，也不会额外提高本来已经生效的属性值。验证：装备一把明确带隐藏属性的武器，对比启用前后的状态面板和对应属性/异常命中表现。来源/状态：由 3DS 静态 ARM #11 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Awaken, releasing a weapon's grayed-out or latent element/status so it participates in the status screen and attack resolution. Scope: weapons without a latent property gain nothing, and already-active element values are not further boosted. Verify: equip a weapon with a known hidden element/status and compare its status entry and matching hit behavior with the pack off and on. Source/status: converted from 3DS static ARM cheat #11; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-14-rock-steady` — 金刚体 / Rock Steady

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-14-rock-steady/manifest.json`
- **Summary / 摘要:** 中文：强制发动原生“金刚体”复合技能，减轻击倒反应，并同时提供风压（小）无效、耳栓（包含煌黑龙吼叫）与水流（小）无效。 状态：Runtime Experimental，默认关闭。 / English: Forces the native Rock Steady compound skill, reducing knockdown reactions while also granting Windproof (Low), Earplugs including Alatreon roars, and Current Resistance (Low). Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动原生“金刚体”复合技能，减轻击倒反应，并同时提供风压（小）无效、耳栓（包含煌黑龙吼叫）与水流（小）无效。边界：它不等同于 #44 风压（大）无效或 #47 耐震，也不保证挡住强制/脚本化吹飞；不要与 #64 同时启用。验证：分别用普通击倒、低级风压、吼叫和低级水流做开关对照。来源/状态：由 3DS 静态 ARM #14 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces the native Rock Steady compound skill, reducing knockdown reactions while also granting Windproof (Low), Earplugs including Alatreon roars, and Current Resistance (Low). Scope: it is not equivalent to #44 Windproof (High) or #47 Tremor Resistance, and forced/scripted launches may still bypass it; do not combine it with #64. Verify: compare ordinary knockdown, low wind pressure, roars, and low water currents separately with the pack off and on. Source/status: converted from 3DS static ARM cheat #14; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-17-theft-immunity` — 偷盗无效 / Theft Immunity

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-17-theft-immunity/manifest.json`
- **Summary / 摘要:** 中文：强制发动偷盗无效，阻止具备偷盗行为的怪物从猎人道具袋中拿走物品。 状态：Runtime Experimental，默认关闭。 / English: Forces Anti-Theft so theft-capable monsters cannot remove items from the hunter's pouch. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动偷盗无效，阻止具备偷盗行为的怪物从猎人道具袋中拿走物品。边界：只拦截物品被偷，不阻止该攻击造成的伤害、硬直或其他异常，也不会返还启用前已经丢失的物品。验证：携带可被偷物品，让梅拉露等偷盗怪成功命中并检查道具数量。来源/状态：由 3DS 静态 ARM #17 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Anti-Theft so theft-capable monsters cannot remove items from the hunter's pouch. Scope: it blocks item loss only, not damage, flinch, or other effects from the same attack, and it cannot restore items stolen before enabling. Verify: carry stealable items, allow a Melynx or another theft-capable monster to land its theft action, and compare pouch counts. Source/status: converted from 3DS static ARM cheat #17; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-18-mud-snow-immunity` — 泥雪无效 / Mud and Snow Immunity

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-18-mud-snow-immunity/manifest.json`
- **Summary / 摘要:** 中文：强制发动泥雪无效，防止猎人进入泥人或雪人束缚状态。 状态：Runtime Experimental，默认关闭。 / English: Forces Negate Mud/Snow, preventing the hunter from entering Muddy or Snowman restraint states. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动泥雪无效，防止猎人进入泥人或雪人束缚状态。边界：不覆盖毒、麻痹、睡眠、元素异常、黏菌或臭气；攻击本身的伤害和击退仍会发生。验证：分别承受会施加泥人和雪人的攻击，确认状态动画与行动限制不再出现。来源/状态：由 3DS 静态 ARM #18 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Negate Mud/Snow, preventing the hunter from entering Muddy or Snowman restraint states. Scope: it does not cover poison, paralysis, sleep, elemental blights, slimeblight, or stench, and the underlying attack can still deal damage or knockback. Verify: take one mud-inflicting and one snow-inflicting attack and confirm the status animation and movement restriction no longer occur. Source/status: converted from 3DS static ARM cheat #18; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-21-evade-extender` — 回避距离 UP / Evade Extender

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-21-evade-extender/manifest.json`
- **Summary / 摘要:** 中文：强制发动回避距离 UP，把多数受支持回避动作的移动距离提高到约原来的 1.5 倍。 状态：Runtime Experimental，默认关闭。 / English: Forces Evade Extender, increasing travel distance for most supported evasive moves to about 1.5x normal. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动回避距离 UP，把多数受支持回避动作的移动距离提高到约原来的 1.5 倍。边界：只增加位移，不增加 #48 回避性能 +2 的无敌时间；不同武器的回避动作与水下动作可能走不同路径。验证：只启用本项并关闭 #65，固定武器、地面、起点、方向和摇杆输入，对比翻滚终点。来源/状态：由 3DS 静态 ARM #21 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Evade Extender, increasing travel distance for most supported evasive moves to about 1.5x normal. Scope: it changes displacement only and does not add #48 Evasion +2 invulnerability; weapon-specific and underwater evasions may use different paths. Verify: enable only this pack, disable #65, keep weapon, terrain, starting point, direction, and stick input fixed, then compare roll endpoints. Source/status: converted from 3DS static ARM cheat #21; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-26-bio-status-immunity` — 细菌感染无效 / Bio Status Immunity

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-26-bio-status-immunity/manifest.json`
- **Summary / 摘要:** 中文：强制发动“细菌学/Bio Master”相关检查，目标是免疫碎龙黏菌（爆破前状态）与臭气，并提高异臭球驱赶效果及相关调和成功率。 状态：Runtime Experimental，默认关闭。 / English: Forces the Biology/Bio Master checks, intended to prevent Brachydios slimeblight and stench while improving Dung Bomb efficacy and its related combination success. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动“细菌学/Bio Master”相关检查，目标是免疫碎龙黏菌（爆破前状态）与臭气，并提高异臭球驱赶效果及相关调和成功率。边界：不免疫黏菌爆炸或攻击的直接伤害，也不覆盖五种元素异常、毒、麻痹和睡眠。验证：分别承受碎龙黏菌与臭气，再用异臭球做开关对照。来源/状态：由 3DS 静态 ARM #26 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces the Biology/Bio Master checks, intended to prevent Brachydios slimeblight and stench while improving Dung Bomb efficacy and its related combination success. Scope: it does not negate direct attack or slime-explosion damage, nor does it cover the five elemental blights, poison, paralysis, or sleep. Verify: separately test a slimeblight hit, a stench source, and Dung Bomb behavior with the pack off and on. Source/status: converted from 3DS static ARM cheat #26; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-27-status-immunity` — 属性异常无效 / Abnormal-Status Immunity

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-27-status-immunity/manifest.json`
- **Summary / 摘要:** 中文：强制发动属性异常无效/Blightproof，阻止火、水、雷、冰、龙五种属性异常附着。 状态：Runtime Experimental，默认关闭。 / English: Forces Blightproof, preventing Fire, Water, Thunder, Ice, and Dragon Blight from being applied. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动属性异常无效/Blightproof，阻止火、水、雷、冰、龙五种属性异常附着。边界：这里只处理元素异常，不处理毒、麻痹、睡眠、眩晕、泥雪、臭气或黏菌；攻击伤害本身仍然结算。验证：用至少两种会施加不同元素异常的攻击做开关对照，检查角色旁状态图标。来源/状态：由 3DS 静态 ARM #27 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Blightproof, preventing Fire, Water, Thunder, Ice, and Dragon Blight from being applied. Scope: this covers elemental blights only, not poison, paralysis, sleep, stun, mud/snow, stench, or slimeblight; the attack itself still deals damage. Verify: compare status icons after attacks that inflict at least two different elemental blights with the pack off and on. Source/status: converted from 3DS static ARM cheat #27; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-33-guard-plus-2` — 防御性能 +2 / Guard +2

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-33-guard-plus-2/manifest.json`
- **Summary / 摘要:** 中文：强制发动防御性能 +2，降低格挡耐力消耗，减少或消除多数攻击的防御削血与后退硬直。 状态：Runtime Experimental，默认关闭。 / English: Forces Guard +2, reducing stamina consumed by blocking and reducing or negating chip damage and knockback from most attacks. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动防御性能 +2，降低格挡耐力消耗，减少或消除多数攻击的防御削血与后退硬直。边界：不会把原本不可防御的攻击变为可防御，那属于 #34 防御强化；无盾武器无法验证。验证：用同一带盾武器格挡同一高冲击攻击，对比耐力、削血和后退距离。来源/状态：由 3DS 静态 ARM #33 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Guard +2, reducing stamina consumed by blocking and reducing or negating chip damage and knockback from most attacks. Scope: it does not make normally unblockable attacks blockable—that is #34 Guard Up—and weapons without a shield cannot validate it. Verify: block the same high-impact attack with the same shielded weapon and compare stamina, chip damage, and pushback. Source/status: converted from 3DS static ARM cheat #33; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-34-guard-up` — 防御强化 / Guard Up

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-34-guard-up/manifest.json`
- **Summary / 摘要:** 中文：强制发动防御强化/Guard Up，使带盾武器能够格挡原本明确不可防御的攻击。 状态：Runtime Experimental，默认关闭。 / English: Forces Guard Up, allowing shielded weapons to block attacks that are explicitly normally unblockable. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动防御强化/Guard Up，使带盾武器能够格挡原本明确不可防御的攻击。边界：不会降低普通格挡的耐力、削血或后退，那属于 #33 防御性能 +2；用普通可防御攻击无法证明本项生效。验证：只启用本项并关闭 #65，用同一带盾武器对同一不可防御攻击做开关对照。来源/状态：由 3DS 静态 ARM #34 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Guard Up, allowing shielded weapons to block attacks that are explicitly normally unblockable. Scope: it does not reduce ordinary block stamina, chip damage, or pushback—that is #33 Guard +2—and a normally blockable attack cannot validate this pack. Verify: enable only this pack, disable #65, and use the same shielded weapon against the same normally unblockable attack in an off/on comparison. Source/status: converted from 3DS static ARM cheat #34; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-35-flaming-aura` — 燃鳞 / Flaming Aura

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-35-flaming-aura/manifest.json`
- **Summary / 摘要:** 中文：强制发动“燃鳞/Flame Aura”，让怪物 AI 把猎人视为正在携带火把，并按各自的火把反应改变行为。 状态：Runtime Experimental，默认关闭。 / English: Forces Flame Aura, making monster AI react to the hunter as though a Torch were being carried. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动“燃鳞/Flame Aura”，让怪物 AI 把猎人视为正在携带火把，并按各自的火把反应改变行为。边界：它不是伤害光环，不会给大型怪物附加燃烧特效，也不是面板数值；不同小怪可能靠近、警戒或逃离，不能只看一种行为。验证：在同一地区选择原本会对火把作出明显反应的小型怪物，对比其接近、回避和攻击节奏。来源/状态：由 3DS 静态 ARM #35 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Flame Aura, making monster AI react to the hunter as though a Torch were being carried. Scope: it is not a damage aura, does not add a visible burn effect to large monsters, and is not a status-screen number; different small monsters may approach, become alert, or flee rather than sharing one response. Verify: use the same area and a small-monster species with a clear native Torch reaction, then compare approach, avoidance, and attack behavior. Source/status: converted from 3DS static ARM cheat #35; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-38-focus` — 蓄力缩短 / Focus

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-38-focus/manifest.json`
- **Summary / 摘要:** 中文：强制发动集中/Focus；大剑、弓、锤的蓄力时间约缩短 20%，太刀、双刀和斩击斧的相关槽增长约加快 20%。 状态：Runtime Experimental，默认关闭。 / English: Forces Focus; Great Sword, Bow, and Hammer charge time is about 20% shorter, while relevant Long Sword, Dual Blade, and Switch Axe gauges fill about 20% faster. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动集中/Focus；大剑、弓、锤的蓄力时间约缩短 20%，太刀、双刀和斩击斧的相关槽增长约加快 20%。边界：不会直接提高单次攻击伤害，且只影响原生 Focus 支持的武器机制。验证：固定武器和输入，分别计时同一蓄力等级或测量同一连段后的槽增长。来源/状态：由 3DS 静态 ARM #38 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Focus; Great Sword, Bow, and Hammer charge time is about 20% shorter, while relevant Long Sword, Dual Blade, and Switch Axe gauges fill about 20% faster. Scope: it does not directly increase per-hit damage and affects only weapon mechanics supported by native Focus. Verify: keep weapon and inputs fixed, then time the same charge level or compare gauge gain after the same combo. Source/status: converted from 3DS static ARM cheat #38; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-41-high-grade-earplugs` — 高级耳栓 / High-Grade Earplugs

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-41-high-grade-earplugs/manifest.json`
- **Summary / 摘要:** 中文：强制发动高级耳栓，使猎人不再因普通和高等级怪物吼叫进入捂耳硬直。 状态：Runtime Experimental，默认关闭。 / English: Forces High-Grade Earplugs so ordinary and high-grade monster roars no longer put the hunter into the hands-over-ears stun. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动高级耳栓，使猎人不再因普通和高等级怪物吼叫进入捂耳硬直。边界：不处理风压、地震、直接攻击或脚本化强制动作；吼叫仍可能保留声音和镜头表现。验证：分别用普通吼叫与原本需要高级耳栓的强吼做开关对照，观察是否失去操作。来源/状态：由 3DS 静态 ARM #41 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces High-Grade Earplugs so ordinary and high-grade monster roars no longer put the hunter into the hands-over-ears stun. Scope: it does not cover wind pressure, tremors, direct attacks, or scripted forced actions; roar audio and camera effects may remain. Verify: compare one ordinary roar and one roar that normally requires High-Grade Earplugs, checking whether control is lost. Source/status: converted from 3DS static ARM cheat #41; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-44-windproof-high` — 风压（大）无效 / Windproof (High)

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-44-windproof-high/manifest.json`
- **Summary / 摘要:** 中文：强制发动风压（大）无效，跳过原生普通小/大风压造成的踉跄和失控。 状态：Runtime Experimental，默认关闭。 / English: Forces Windproof (High), bypassing the stagger and control loss from native ordinary low/high wind-pressure checks. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动风压（大）无效，跳过原生普通小/大风压造成的踉跄和失控。边界：煌黑龙等特殊或脚本化吹倒可能绕过这些普通风压检查；它也不处理吼叫、地震或直接攻击击退。验证：先用明确的普通大风压攻击做开关对照，不要把煌黑龙特殊吹倒作为唯一判据。来源/状态：由 3DS 静态 ARM #44 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Windproof (High), bypassing the stagger and control loss from native ordinary low/high wind-pressure checks. Scope: special or scripted blowdowns such as Alatreon's may bypass those checks, and this does not cover roars, tremors, or direct-attack knockback. Verify: first compare a known ordinary high-wind-pressure attack with the pack off and on rather than using Alatreon's special blowdown as the sole test. Source/status: converted from 3DS static ARM cheat #44; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-45-stun-immunity` — 眩晕和气绝无效 / Stun Immunity

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-45-stun-immunity/manifest.json`
- **Summary / 摘要:** 中文：强制发动眩晕无效，阻止多次受击累积后出现头冒星星、无法操作的气绝状态。 状态：Runtime Experimental，默认关闭。 / English: Forces Stun Immunity, preventing the stars-over-head incapacitation caused by accumulated stun from repeated hits. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动眩晕无效，阻止多次受击累积后出现头冒星星、无法操作的气绝状态。边界：不阻止单次攻击的普通硬直、击飞、倒地或雷属性异常，也不减少攻击伤害。验证：在可控条件下连续承受容易积累眩晕值的攻击，对比是否出现眩晕动画和摇杆恢复提示。来源/状态：由 3DS 静态 ARM #45 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Stun Immunity, preventing the stars-over-head incapacitation caused by accumulated stun from repeated hits. Scope: it does not prevent normal flinch, launch, knockdown, Thunder Blight, or damage from each hit. Verify: under controlled conditions, take repeated high-stun attacks and compare whether the stun animation and recovery prompt appear. Source/status: converted from 3DS static ARM cheat #45; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-46-poison-paralysis-sleep-immunity` — 毒、麻痹、睡眠无效 / Poison, Paralysis, and Sleep Immunity

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-46-poison-paralysis-sleep-immunity/manifest.json`
- **Summary / 摘要:** 中文：同时强制毒无效、麻痹无效和睡眠无效，阻止这三种状态异常附着。 状态：Runtime Experimental，默认关闭。 / English: Simultaneously forces Negate Poison, Negate Paralysis, and Negate Sleep, preventing all three ailments from being applied. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：同时强制毒无效、麻痹无效和睡眠无效，阻止这三种状态异常附着。边界：不覆盖眩晕（#45）、五种元素异常（#27）、泥雪（#18）、臭气或黏菌（#26）；攻击本体伤害仍然结算。验证：分别承受稳定施加毒、麻痹和睡眠的来源，逐项检查状态图标与行动限制。来源/状态：由 3DS 静态 ARM #46 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: simultaneously forces Negate Poison, Negate Paralysis, and Negate Sleep, preventing all three ailments from being applied. Scope: it does not cover stun (#45), the five elemental blights (#27), mud/snow (#18), stench, or slimeblight (#26), and the underlying hit still deals damage. Verify: separately use reliable poison, paralysis, and sleep sources and check each status icon and control restriction. Source/status: converted from 3DS static ARM cheat #46; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-47-tremor-resistance` — 耐震 / Tremor Resistance

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-47-tremor-resistance/manifest.json`
- **Summary / 摘要:** 中文：强制发动耐震，阻止大型怪物制造的地面震动让猎人踉跄并短暂失去操作。 状态：Runtime Experimental，默认关闭。 / English: Forces Tremor Resistance, preventing large-monster ground tremors from staggering the hunter and briefly removing control. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动耐震，阻止大型怪物制造的地面震动让猎人踉跄并短暂失去操作。边界：只处理地震判定，不处理吼叫、风压、直接撞击或地形伤害。验证：站在同一怪物同一震地动作的有效范围内，对比启用前后的踉跄动画与可操作时间。来源/状态：由 3DS 静态 ARM #47 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Tremor Resistance, preventing large-monster ground tremors from staggering the hunter and briefly removing control. Scope: it covers tremor checks only, not roars, wind pressure, direct impacts, or terrain damage. Verify: stand within the effective range of the same monster's same ground-slam and compare stagger animation and time-to-control. Source/status: converted from 3DS static ARM cheat #47; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-48-evasion-plus-2` — 回避性能 +2 / Evasion +2

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-48-evasion-plus-2/manifest.json`
- **Summary / 摘要:** 中文：强制发动回避性能 +2，把原生多数回避动作的无敌时间从约 0.2 秒提高到约 0.4 秒。 状态：Runtime Experimental，默认关闭。 / English: Forces Evasion +2, increasing the native invulnerability window of most evasive moves from roughly 0.2 seconds to roughly 0.4 seconds. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动回避性能 +2，把原生多数回避动作的无敌时间从约 0.2 秒提高到约 0.4 秒。边界：只延长无敌窗口，不增加回避移动距离，那属于 #21 回避距离 UP；持续时间很长或多段攻击仍可能在窗口外命中。验证：固定武器和同一攻击时机，逐步提前/延后翻滚，比较可穿过攻击的时间窗口。来源/状态：由 3DS 静态 ARM #48 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Evasion +2, increasing the native invulnerability window of most evasive moves from roughly 0.2 seconds to roughly 0.4 seconds. Scope: it extends invulnerability only and does not increase travel distance—that is #21 Evade Extender; long or multi-hit attacks can still connect outside the window. Verify: keep weapon and attack fixed, vary roll timing around the same hit, and compare the range of timings that pass through safely. Source/status: converted from 3DS static ARM cheat #48; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-51-minds-eye` — 近战不弹刀 / Mind's Eye

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-51-minds-eye/manifest.json`
- **Summary / 摘要:** 中文：强制发动心眼，使近战攻击命中高硬度肉质时不再触发弹刀动作，连段可以继续。 状态：Runtime Experimental，默认关闭。 / English: Forces Mind's Eye so melee attacks no longer bounce from hard hitzones and the combo can continue. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动心眼，使近战攻击命中高硬度肉质时不再触发弹刀动作，连段可以继续。边界：不会提高实际伤害或武器锋利度，斩味仍会消耗（除非另启 #5），远程武器也不受益。验证：使用低斩味近战武器反复攻击一个稳定会弹刀的部位，对比动作是否被打断。来源/状态：由 3DS 静态 ARM #51 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Mind's Eye so melee attacks no longer bounce from hard hitzones and the combo can continue. Scope: it does not raise actual damage or weapon sharpness, sharpness still drains unless #5 is enabled, and ranged weapons do not benefit. Verify: use a low-sharpness melee weapon against a hitzone that reliably causes bounces and compare animation interruption. Source/status: converted from 3DS static ARM cheat #51; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-63-climate-temperature-adaptation` — 气候温度适应 / Climate and Temperature Adaptation

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-63-climate-temperature-adaptation/manifest.json`
- **Summary / 摘要:** 中文：同时强制耐暑与耐寒相关检查，使猎人在炎热/寒冷地图中无需冷饮或热饮也不受环境持续伤害、熔岩热伤害及寒冷额外耐力消耗。 状态：Runtime Experimental，默认关闭。 / English: Forces both heat- and cold-cancel checks so hot/cold maps no longer require Cool/Hot Drinks to avoid environmental health drain, lava heat damage, or cold-driven stamina penalties. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：同时强制耐暑与耐寒相关检查，使猎人在炎热/寒冷地图中无需冷饮或热饮也不受环境持续伤害、熔岩热伤害及寒冷额外耐力消耗。边界：不免疫怪物的火/冰攻击，也不阻止火、水、雷、冰、龙属性异常（见 #27）。验证：不喝温度饮料，分别在炎热熔岩区和寒冷区停留并观察 HP、耐力上限与消耗。来源/状态：由 3DS 静态 ARM #63 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces both heat- and cold-cancel checks so hot/cold maps no longer require Cool/Hot Drinks to avoid environmental health drain, lava heat damage, or cold-driven stamina penalties. Scope: it does not negate monster fire/ice attacks or the five elemental blights (#27). Verify: use no temperature drink, remain in both a hot lava zone and a cold zone, and observe HP, maximum stamina, and drain. Source/status: converted from 3DS static ARM cheat #63; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-64-rock-steady-activated` — 金刚身发动 / Rock Steady Activated

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/03-skills-and-immunities/static-64-rock-steady-activated/manifest.json`
- **Summary / 摘要:** 中文：把一条“金刚身发动”最终失败返回直接改为成功，目标是在正常条件不满足时仍通过该底层发动判定。 状态：Runtime Experimental，默认关闭。 / English: Changes one final “Rock Steady activated” failure return to success, aiming to pass that low-level activation predicate even when normal conditions fail. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：把一条“金刚身发动”最终失败返回直接改为成功，目标是在正常条件不满足时仍通过该底层发动判定。边界：这是单一最终返回路径，不是 #14 对金刚体效果 ID 七个调用点的完整强制；实际覆盖的击倒、风压、吼叫或水流场景可能更窄，且不可与 #14 同时启用。验证：单独启用本项，对普通击倒、低风压、吼叫和低水流逐项做开关对照。来源/状态：由 3DS 静态 ARM #64 精确转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: changes one final “Rock Steady activated” failure return to success, aiming to pass that low-level activation predicate even when normal conditions fail. Scope: this is a single final-return path, not #14's seven-callsite force of the Rock Steady effect ID; actual knockdown, wind, roar, or current coverage may be narrower, and it must not be combined with #14. Verify: enable this pack alone and compare ordinary knockdown, low wind, roars, and low currents one by one. Source/status: exact conversion of 3DS static ARM cheat #64; Disabled by default; Runtime Experimental and requires gameplay verification.

## `04-combat-and-weapons` — 战斗与武器 / Combat and Weapons

针对武器机制、弹药、锋利度、后坐力及会心的专项调整。 / Focused changes to weapon mechanics, ammunition, sharpness, recoil, and affinity.

Pack count / 插件数: **8** (available / 可用: 8; runtime-blocked / 运行时阻塞: 0).

### `mh3g-hd-jp-v96-dynamic-24-30-weapon-auto-refill` — 铳枪/轻弩/重弩自动补弹 V10 / Weapon Auto Refill V10

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/04-combat-and-weapons/dynamic-24-30-weapon-auto-refill/manifest.json`
- **Summary / 摘要:** 中文：铳枪开火后自动补回炮弹；轻弩和重弩普通射击后自动回填当前弹仓，同时真实弹药仍按原版逐发消耗，回填量不超过弹仓容量与当前备弹中的较小值。 状态：Runtime Experimental，默认关闭；用户接受姿态切换附近可能约 1～2 发同步延迟作为当前已知限制，皮皮鸟独立复测待回执。 / English: Automatically refills Gunlance shells and the current LBG/HBG magazine after normal shots while real ammunition is still consumed one round at a time, clamped to the smaller of magazine capacity and current reserve. Status: Runtime Experimental; disabled by default. The user accepts a possible one-to-two-shot sync delay around stance changes as the current known limitation; independent PipiNiao retest feedback is pending.

**Full description / 完整说明**

中文：效果：铳枪开火后自动补回炮弹；轻弩和重弩普通射击后自动回填当前弹仓，同时真实弹药仍按原版逐发消耗，回填量不超过弹仓容量与当前备弹中的较小值。边界：V10 为当前冻结的外部复测候选；重弩蹲射及姿态切换会共同维护多组原生弹仓与动作状态，用户已接受姿态切换前后可能出现约 1～2 发的状态或显示同步延迟作为当前已知限制，但是否源自 MH3G 原版尚未证实。真实备弹为零时不应无限生成弹丸；若复测仍出现持续开火、负数弹槽或卡死，应按失败回报而不是视为该限制。不得与 #25 子弹不减、#52 弓瓶自动装填、旧 V1～V9 或其他弹药状态 Pack 同时启用。验证：冷启动后只启用本项；分别验证铳枪、轻弩和重弩普通射击，再用火炎弹及至少一种其他可蹲射弹种保持蹲姿打到真实备弹为零，确认随后不能持续生成弹丸；切换普通/蹲射姿态和弹种，记录是否仅有 1～2 发延迟，以及左上弹槽、真实备弹、装填动作、卡死或崩溃。来源/状态：由 3DS #24/#30 语义映射到固定 JP v96 PPC 原生弹药事务；V10 已通过 11/11 hook 前像、Cemu PPCAssembler 与结构/语义门槛，并由用户接受作为外部复测候选，但尚未取得皮皮鸟独立通过回执；默认关闭；Runtime Experimental。 / English: Effect: Automatically refills Gunlance shells and the current LBG/HBG magazine after normal shots while real ammunition is still consumed one round at a time, clamped to the smaller of magazine capacity and current reserve.Scope: V10 is the frozen external-retest candidate. HBG siege fire and stance transitions share multiple native magazine/action states. The user accepts a possible one-to-two-shot state or HUD synchronization delay around stance changes as the current known limitation, but a vanilla-game origin is unproven. Zero real reserve must not permit indefinite projectile generation; continued fire, a negative counter, a stuck state, or a crash remains a failure rather than this accepted delay. Do not combine with #25, #52, V1-V9, or another ammunition-state pack. Verify: cold-start with only this pack enabled; test Gunlance, LBG, and normal HBG fire, then hold siege stance with Flaming S and at least one other supported ammo type until real reserve reaches zero and confirm firing cannot continue indefinitely. Switch normal/siege stance and ammo, recording whether the only anomaly is a one-to-two-shot delay plus the HUD count, real reserve, reload behavior, hangs, and crashes. Source/status: maps 3DS #24/#30 semantics onto fixed JP-v96 PPC native ammunition transactions. V10 passes 11/11 hook preimages plus Cemu PPCAssembler and structural/semantic gates and was accepted by the user for external retest, but has no independent PipiNiao pass yet. Disabled by default; Runtime Experimental.

### `mh3g-hd-jp-v96-static-05-sharpness-never-decreases` — 锋利度不减 / Sharpness Never Decreases

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/04-combat-and-weapons/static-05-sharpness-never-decreases/manifest.json`
- **Summary / 摘要:** 中文：阻止近战攻击后的常规锋利度递减写回，使启用后的斩味条不再因命中或弹刀而下降。 状态：Runtime Experimental，默认关闭。 / English: Suppresses the normal sharpness-decrement writeback after melee attacks, keeping the enabled weapon's sharpness gauge from falling on hits or bounces. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：阻止近战攻击后的常规锋利度递减写回，使启用后的斩味条不再因命中或弹刀而下降。边界：不会提高武器初始斩味等级，也不会恢复启用前已经损失的斩味；特殊脚本消耗仍需单独确认。验证：用同一近战武器在同一硬度部位连续攻击，对比启用前后的斩味条变化。来源/状态：由 3DS 静态 ARM #5 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: suppresses the normal sharpness-decrement writeback after melee attacks, keeping the enabled weapon's sharpness gauge from falling on hits or bounces. Scope: it does not raise the weapon's starting sharpness tier or restore sharpness already lost before enabling; scripted consumption remains to be checked. Verify: use the same melee weapon and repeatedly hit the same hitzone, then compare gauge loss with the pack off and on. Source/status: converted from 3DS static ARM cheat #5; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-06-critical-display-hidden` — 会心不显示 / Critical Display Hidden

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/04-combat-and-weapons/static-06-critical-display-hidden/manifest.json`
- **Summary / 摘要:** 中文：虽然 3DS 源名称写作“会心不显示”，实际代码会把两条会心加成路径由 30 改为 100，当前行为等同于 #72“会心率 100%”，并不会隐藏会心特效。 状态：Runtime Experimental，默认关闭。 / English: Despite the 3DS source label “Critical Display Hidden,” the code changes two affinity-add paths from 30 to 100; it currently behaves like #72 Affinity 100% and does not hide critical-hit effects. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：虽然 3DS 源名称写作“会心不显示”，实际代码会把两条会心加成路径由 30 改为 100，当前行为等同于 #72“会心率 100%”，并不会隐藏会心特效。边界：#6 与 #72 修改同一组 Wii U 指令，严禁同时启用；最终面板值仍可能受武器负会心与游戏上限处理影响。验证：使用零会心或负会心武器，对比状态面板与连续命中的会心闪光频率。来源/状态：由 3DS 静态 ARM #6 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: despite the 3DS source label “Critical Display Hidden,” the code changes two affinity-add paths from 30 to 100; it currently behaves like #72 Affinity 100% and does not hide critical-hit effects. Scope: #6 and #72 patch the same Wii U instructions and must never be enabled together; negative weapon affinity and game-side caps may still affect the displayed result. Verify: use a zero- or negative-affinity weapon and compare both the status value and critical-flash frequency over repeated hits. Source/status: converted from 3DS static ARM cheat #6; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-29-power-coating-anywhere` — 任何地方可用电阻弹 / Power Coating Usable Anywhere

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/04-combat-and-weapons/static-29-power-coating-anywhere/manifest.json`
- **Summary / 摘要:** 中文：把弓的强击瓶（3DS 源中文误写作“电阻弹”）可用性判定强制为真，使原本不支持强击瓶的弓也能装填并使用它。 状态：Runtime Experimental，默认关闭。 / English: Forces Power Coating compatibility true, allowing a bow that normally rejects Power Coating to load and fire it; the 3DS Chinese source label mistranslates this as “resistance ammo.” Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：把弓的强击瓶（3DS 源中文误写作“电阻弹”）可用性判定强制为真，使原本不支持强击瓶的弓也能装填并使用它。边界：不会凭空生成强击瓶数量，不解锁其他瓶种，也不替代 #52 的弓瓶自动装填。验证：选择武器面板明确不支持强击瓶的弓，携带强击瓶进任务并尝试装填、射击和确认消耗。来源/状态：由 3DS 静态 ARM #29 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Power Coating compatibility true, allowing a bow that normally rejects Power Coating to load and fire it; the 3DS Chinese source label mistranslates this as “resistance ammo.” Scope: it does not create coating inventory, unlock other coating types, or replace #52 bow-coating auto-load. Verify: use a bow whose equipment panel does not support Power Coating, bring actual coatings, then confirm loading, firing, and item consumption. Source/status: converted from 3DS static ARM cheat #29; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-49-minimum-bowgun-recoil` — 弩后坐力最小 / Minimum Bowgun Recoil

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/04-combat-and-weapons/static-49-minimum-bowgun-recoil/manifest.json`
- **Summary / 摘要:** 中文：把轻/重弩射击后的后坐力压到原生支持的最小档，缩短枪口上扬和开火后恢复时间。 状态：Runtime Experimental，默认关闭。 / English: Reduces Light/Heavy Bowgun firing recoil to the lowest native level, shortening muzzle rise and post-shot recovery. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：把轻/重弩射击后的后坐力压到原生支持的最小档，缩短枪口上扬和开火后恢复时间。边界：不改变弹道左右偏移（#50）、装填速度、弹容量或瞄准镜移动；使用本来就低后坐力的弹看不出差异。验证：选择面板后坐力高且会产生明显停顿的弹种，比较连续射击间隔和角色后仰。来源/状态：由 3DS 静态 ARM #49 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: reduces Light/Heavy Bowgun firing recoil to the lowest native level, shortening muzzle rise and post-shot recovery. Scope: it does not change left/right shot deviation (#50), reload speed, magazine capacity, or scope movement, and naturally low-recoil ammo may show no difference. Verify: use an ammo type with clearly high listed recoil and compare post-shot kick and repeat-fire interval. Source/status: converted from 3DS static ARM cheat #49; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-50-bowgun-steadiness` — 弩无摇晃 / Bowgun Steadiness

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/04-combat-and-weapons/static-50-bowgun-steadiness/manifest.json`
- **Summary / 摘要:** 中文：强制发动弩稳准/Steadiness，把面板自带的左右弹道偏移压低或消除，使远距离弹着更贴近准星。 状态：Runtime Experimental，默认关闭。 / English: Forces bowgun Steadiness, reducing or eliminating built-in left/right projectile deviation so long-range impacts track the reticle more closely. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动弩稳准/Steadiness，把面板自带的左右弹道偏移压低或消除，使远距离弹着更贴近准星。边界：这里的“无摇晃”指射弹偏移，不是镜头抖动，也不改变 #49 后坐力、装填速度或零偏移弩。验证：只启用本项并关闭 #65，使用自带左右偏移的弩对远处固定目标连续射击并比较散布。来源/状态：由 3DS 静态 ARM #50 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces bowgun Steadiness, reducing or eliminating built-in left/right projectile deviation so long-range impacts track the reticle more closely. Scope: “steadiness” means shot deviation, not camera shake, and it does not change #49 recoil, reload speed, or a bowgun that already has zero deviation. Verify: enable only this pack, disable #65, use a bowgun with built-in left/right deviation, and compare repeated long-range impacts on a fixed target. Source/status: converted from 3DS static ARM cheat #50; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-52-bow-auto-reload` — 弓箭自填 / Bow Auto-Reload

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/04-combat-and-weapons/static-52-bow-auto-reload/manifest.json`
- **Summary / 摘要:** 中文：强制弓进入装填速度 +2 级别的瓶装填语义；切换选中的弓瓶时会自动装上，不必再执行手动装填动作。 状态：Runtime Experimental，默认关闭。 / English: Forces the bow-side Reload Speed +2 coating semantic, automatically applying a selected coating without the manual load animation. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制弓进入装填速度 +2 级别的瓶装填语义；切换选中的弓瓶时会自动装上，不必再执行手动装填动作。边界：不会生成瓶数量，也不会让武器使用原本不兼容的瓶（强击瓶兼容见 #29）；同一效果 ID 也可能影响弩装填路径，需单独观察。验证：携带至少两种该弓原生兼容的瓶，在持弓状态切换选择，确认瓶立即生效并正常消耗。来源/状态：由 3DS 静态 ARM #52 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces the bow-side Reload Speed +2 coating semantic, automatically applying a selected coating without the manual load animation. Scope: it does not create coating inventory or make an incompatible coating usable (#29 covers Power Coating compatibility); the shared effect ID may also touch bowgun reload paths and needs separate observation. Verify: bring at least two coatings natively supported by the bow, switch selections while the bow is drawn, and confirm immediate application and normal consumption. Source/status: converted from 3DS static ARM cheat #52; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-72-affinity-100` — 会心率 100% / Affinity 100%

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/04-combat-and-weapons/static-72-affinity-100/manifest.json`
- **Summary / 摘要:** 中文：强制两条会心技能检查并把会心加成从 30 改为 100，目标是让武器达到或接近 100% 会心率，连续攻击几乎每次触发正会心。 状态：Runtime Experimental，默认关闭。 / English: Forces both affinity-skill checks and changes the affinity addition from 30 to 100, aiming for 100% or near-100% affinity so almost every repeated hit becomes a positive critical. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制两条会心技能检查并把会心加成从 30 改为 100，目标是让武器达到或接近 100% 会心率，连续攻击几乎每次触发正会心。边界：Wii U 编译结果与 #6 使用完全相同的路径，两项当前等效且严禁同时启用；负会心武器和游戏上限处理可能影响面板最终值。验证：使用零会心和负会心武器分别对比状态面板与连续命中的会心闪光频率。来源/状态：由 3DS 静态 ARM #72 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces both affinity-skill checks and changes the affinity addition from 30 to 100, aiming for 100% or near-100% affinity so almost every repeated hit becomes a positive critical. Scope: the Wii U build uses exactly the same paths as #6, making the two currently equivalent and mutually exclusive; negative-affinity weapons and game-side caps may alter the final displayed value. Verify: use both zero- and negative-affinity weapons and compare the status value and critical-flash frequency across repeated hits. Source/status: converted from 3DS static ARM cheat #72; Disabled by default; Runtime Experimental and requires gameplay verification.

## `05-balance-breaking` — 破坏平衡 / Balance Breaking

显著绕过正常成长的资源、经济、生存或广域战斗覆盖。 / Resource, economy, survival, or broad combat overrides that materially bypass normal progression.

Pack count / 插件数: **10** (available / 可用: 10; runtime-blocked / 运行时阻塞: 0).

### `mh3g-hd-jp-v96-equipment-crafting-upgrade-no-materials` — 装备制造与强化无需材料（含生产解锁） / Craft and Upgrade Without Materials (Includes Production Unlock)

- **Status / 状态:** Runtime Verified
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/05-balance-breaking/equipment-crafting-upgrade-no-materials/manifest.json`
- **Summary / 摘要:** 中文：把装备生产与强化所用的非豁免材料数量判定伪装为 99，并附带装备生产全解锁；2026-08-11 更正实测确认，零材料时也能生产和强化，实际持有的真实材料不会被扣除。 状态：Runtime Verified，默认关闭。 / English: Spoofs the non-exempt material-availability checks used by equipment production and upgrade as 99 and bundles production unlock; corrected gameplay evidence on 2026-08-11 confirmed that both actions work with zero materials and do not deduct real materials already owned. Status: Runtime Verified; disabled by default.

**Full description / 完整说明**

中文：效果：把装备生产与强化所用的非豁免材料数量判定伪装为 99，并附带装备生产全解锁；2026-08-11 更正实测确认，零材料时也能生产和强化，实际持有的真实材料不会被扣除。边界：不向背包或仓库生成物品；3DS 原版铁匠铺会受共享 ARM 钩子影响而显示全 99，但 JP-v96 PPC 版界面保持真实持有数量，没有 99、空白或错误显示；本包已包含独立“生产全解锁”补丁，二者不能同时启用，金钱仍按原规则处理。验证：只启用本项并完整重载标题，分别用零材料配方完成一次生产和一次强化，再用至少拥有一个真实材料的配方操作并确认数量不减少；同时检查铁匠铺和其他数量界面，关闭并重启后确认材料限制恢复。来源/状态：由外部 3DS ARM code cave、直接解锁位补丁和仓库计数补丁映射为 JP v96 的 28 条固定 PPC 写入，并保留源代码唯一的真实数量豁免调用；默认关闭；Runtime Verified / Gameplay Passed。 / English: Effect: spoofs the non-exempt material-availability checks used by equipment production and upgrade as 99 and bundles production unlock; corrected gameplay evidence on 2026-08-11 confirmed that both actions work with zero materials and do not deduct real materials already owned. Scope: it creates no pouch or item-box item; the original 3DS shared ARM hook makes the smithy display all 99, while the JP-v96 PPC UI keeps real owned counts with no 99, blank, or corrupt display. It already includes Production Unlock and must not be combined with that independent pack; money rules remain native. Verify: enable only this pack, fully reload, complete one production and one upgrade with zero materials, then use a recipe for which at least one real material is owned and confirm the count does not decrease; inspect smithy and other quantity screens, then disable and restart to confirm native material gating returns. Source/status: maps the external 3DS ARM code cave, direct unlock-bit patch, and item-box count patch to twenty-eight fixed JP-v96 PPC writes while preserving the source's unique real-count exemption; Disabled by default; Runtime Verified / Gameplay Passed.

### `mh3g-hd-jp-v96-equipment-crafting-upgrade-no-money` — 装备制造与强化无需金钱 / Craft and Upgrade Without Money

- **Status / 状态:** Runtime Verified
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/05-balance-breaking/equipment-crafting-upgrade-no-money/manifest.json`
- **Summary / 摘要:** 中文：让装备生产与强化候选的费用显示为 `0z`，低余额也能执行，操作前后钱包保持不变；2026-08-12 本机冷启动实测确认此前只对生产生效的问题已由 V7 修复，生产与强化核心路径均通过。 状态：Runtime Verified，默认关闭。 / English: Makes equipment production and upgrade candidates display `0z`, permits execution with insufficient wallet balance, and leaves the wallet unchanged; a local cold-start test on 2026-08-12 confirmed that V7 fixes the former production-only result and passes the core production and upgrade paths. Status: Runtime Verified; disabled by default.

**Full description / 完整说明**

中文：效果：让装备生产与强化候选的费用显示为 `0z`，低余额也能执行，操作前后钱包保持不变；2026-08-12 本机冷启动实测确认此前只对生产生效的问题已由 V7 修复，生产与强化核心路径均通过。边界：真实材料仍按原规则检查和扣除，材料不足时仍会阻止操作，除非另行启用“无需材料”；本包不修改武器攻击力、人物面板、共享装备价值、出售/退款价格或钱包调整器。当前结果覆盖核心生产/强化路径，但不冒充所有装备类别与 NPC 路线的穷举验证。验证：只启用 V7 并完整重载标题，把钱包降到低于费用，选择材料充足的生产和强化各至少一项，记录操作前后价格、钱包、材料、武器攻击力与人物面板；再跨至少两种武器类别复测，关闭重启后确认原价和余额限制恢复。来源/状态：V1 至 V6 的全局值和通用详情猜测均已由异常或实测否定；V7 通过客机堆搜索与硬件读监视点锁定所选对象 `+0x31C` 及真实候选生成器 `0x0221C730`，只保留六个局部费用调用；默认关闭；Runtime Verified / Gameplay Passed。 / English: Effect: makes equipment production and upgrade candidates display `0z`, permits execution with insufficient wallet balance, and leaves the wallet unchanged; a local cold-start test on 2026-08-12 confirmed that V7 fixes the former production-only result and passes the core production and upgrade paths. Scope: real materials remain checked and deducted normally, so missing materials still block the action unless No Materials is enabled separately; this pack does not alter weapon attack, hunter status, shared equipment value, sale/refund prices, or the wallet adjuster. Current evidence covers the core production/upgrade routes but is not an exhaustive pass over every equipment category or NPC route. Verify: enable only V7, fully reload, lower the wallet below the fee, and perform at least one material-sufficient production and upgrade while recording displayed price, wallet, materials, weapon attack, and hunter status before and after; repeat across at least two weapon categories, then disable and restart to confirm native prices and balance gating return. Source/status: global-value and generic-detail guesses from V1 through V6 were rejected by anomalies or gameplay tests; V7 used a guest-heap search and hardware read watchpoint to pin selected-object `+0x31C` and actual candidate builder `0x0221C730`, retaining only six local cost calls; Disabled by default; Runtime Verified / Gameplay Passed.

### `mh3g-hd-jp-v96-equipment-production-unlock` — 装备生产全解锁 / Unlock All Equipment Production

- **Status / 状态:** Runtime Verified
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/05-balance-breaking/equipment-production-unlock/manifest.json`
- **Summary / 摘要:** 中文：让所有合法装备 ID 通过生产配方的进度解锁位检查，从而显示并允许选择正常流程中尚未解锁的装备生产项目；关闭后恢复原进度，不向存档永久写入解锁表。 状态：Runtime Verified，默认关闭。 / English: Makes every valid equipment ID pass the production-recipe progression-unlock bit test, exposing production entries that normal progression has not unlocked; disabling it restores native progression and does not permanently write the save unlock table. Status: Runtime Verified; disabled by default.

**Full description / 完整说明**

中文：效果：让所有合法装备 ID 通过生产配方的进度解锁位检查，从而显示并允许选择正常流程中尚未解锁的装备生产项目；关闭后恢复原进度，不向存档永久写入解锁表。边界：不提供材料或金钱，不解锁任务、商店库存或其他系统；“无需材料”包已经包含同一解锁补丁，不能同时启用。验证：只启用本项并完整重载标题，在铁匠铺记录原本未解锁项目是否出现，再选择一项材料和金钱充足的装备完成生产；同时检查已解锁列表、其他商店/任务页面及关闭重启后的恢复情况。2026-08-11 实机反馈确认功能正常，未观察到崩溃、空白或错误界面。来源/状态：由外部 3DS Gateway 指针循环写入语义转换到 JP v96 原生 PPC 解锁位读取；默认关闭；Runtime Verified / Gameplay Passed。 / English: Effect: makes every valid equipment ID pass the production-recipe progression-unlock bit test, exposing production entries that normal progression has not unlocked; disabling it restores native progression and does not permanently write the save unlock table. Scope: it grants neither materials nor money and does not unlock quests, shop stock, or unrelated systems; No Materials already includes the same unlock patch and must not be enabled together. Verify: enable only this pack, fully reload, confirm previously locked entries appear at the smithy, and produce one entry for which money and materials are sufficient; also inspect already-unlocked entries, unrelated shop/quest screens, and restoration after disabling and restarting. Gameplay feedback on 2026-08-11 confirmed the intended behavior with no crash, blank, or corrupt UI. Source/status: converted from the external 3DS Gateway pointer-loop semantic to the native JP-v96 PPC unlock-bit read; Disabled by default; Runtime Verified / Gameplay Passed.

### `mh3g-hd-jp-v96-static-07-infinite-hp` — HP 无限 / Infinite HP

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/05-balance-breaking/static-07-infinite-hp/manifest.json`
- **Summary / 摘要:** 中文：同时阻止受伤后的常规当前 HP 写回，以及超量伤害把 HP 强制归零的致死写回，目标是在普通与一击致死伤害下都保持当前 HP。 状态：Runtime Experimental，默认关闭。 / English: Blocks both the normal current-HP writeback after damage and the lethal zero-clamp used for overkill, aiming to preserve HP against ordinary and otherwise fatal hits. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：同时阻止受伤后的常规当前 HP 写回，以及超量伤害把 HP 强制归零的致死写回，目标是在普通与一击致死伤害下都保持当前 HP。边界：治疗写回也可能被同一路径拦截，任务脚本、坠落或其他非普通 HP 失败条件不保证被覆盖。验证：分别承受小额伤害、明显超量伤害并使用回复道具，观察 HP 与任务状态。来源/状态：由 3DS 静态 ARM #7 增强转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: blocks both the normal current-HP writeback after damage and the lethal zero-clamp used for overkill, aiming to preserve HP against ordinary and otherwise fatal hits. Scope: healing may share the suppressed writeback, while scripted quest failure, falling, or other nonstandard defeat conditions are not guaranteed to be covered. Verify: separately take minor damage, a clearly lethal hit, and then use a healing item while observing HP and quest state. Source/status: enhanced conversion of 3DS static ARM cheat #7; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-15-unbreakable-pickaxes-bug-nets` — 铁镐和虫网不会损坏 / Unbreakable Pickaxes and Bug Nets

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/05-balance-breaking/static-15-unbreakable-pickaxes-bug-nets/manifest.json`
- **Summary / 摘要:** 中文：把铁镐和虫网的耐久余量固定为 100，并强制相关损坏保护检查，使采矿和捕虫使用后不再随机损坏工具。 状态：Runtime Experimental，默认关闭。 / English: Fixes pickaxe and bug-net durability remainder at 100 and forces the related break-protection checks so mining and bug catching no longer randomly destroy those tools. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：把铁镐和虫网的耐久余量固定为 100，并强制相关损坏保护检查，使采矿和捕虫使用后不再随机损坏工具。边界：不会让采集点无限刷新，也不会增加每次采集数量；鱼叉、回旋镖、笛等共享“反复无常”体系的物品是否受影响仍需观察。验证：携带最低级铁镐和虫网，在同一任务中连续采矿、捕虫直到正常应出现损坏。来源/状态：由 3DS 静态 ARM #15 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: fixes pickaxe and bug-net durability remainder at 100 and forces the related break-protection checks so mining and bug catching no longer randomly destroy those tools. Scope: it does not make gathering nodes infinite or increase yield per gather; possible effects on harpoons, boomerangs, flutes, or other Whim-family items remain to be observed. Verify: bring the lowest-grade pickaxe and bug net and use each repeatedly in one quest beyond the point where breakage normally occurs. Source/status: converted from 3DS static ARM cheat #15; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-16-max-health-150` — 体力上限 150 / Maximum Health 150

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/05-balance-breaking/static-16-max-health-150/manifest.json`
- **Summary / 摘要:** 中文：强制发动体力 +50 语义，把猎人最大 HP 提升到自然上限 150，不再依赖猫饭或营养剂补足上限。 状态：Runtime Experimental，默认关闭。 / English: Forces the Health +50 semantic, raising the hunter's maximum HP to the natural cap of 150 without relying on a meal or Nutrients. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动体力 +50 语义，把猎人最大 HP 提升到自然上限 150，不再依赖猫饭或营养剂补足上限。边界：主要改变最大值，进入任务时当前 HP 是否同步补满取决于原生初始化/回复路径；不会提供 #7 的锁血效果。验证：使用基础 100 HP 配置进入任务，对比血条上限，并在受伤后回复确认当前值可达 150。来源/状态：由 3DS 静态 ARM #16 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces the Health +50 semantic, raising the hunter's maximum HP to the natural cap of 150 without relying on a meal or Nutrients. Scope: it primarily changes the maximum; whether current HP is filled immediately depends on native initialization/healing, and it does not provide #7's HP lock. Verify: enter a quest from a 100-HP baseline, compare the gauge cap, then take damage and heal to confirm the current value can reach 150. Source/status: converted from 3DS static ARM cheat #16; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-37-infinite-stamina` — 耐力无限 / Infinite Stamina

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/05-balance-breaking/static-37-infinite-stamina/manifest.json`
- **Summary / 摘要:** 中文：把相关耐力条件强制为真并持续走最大耐力写回，目标是让奔跑、蓄力、翻滚、格挡和水下动作不再因耐力耗尽而中断。 状态：Runtime Experimental，默认关闭。 / English: Forces the relevant stamina condition true and keeps taking the maximum-stamina writeback, aiming to prevent sprinting, charging, repeated evasion, guarding, and underwater actions from stopping due to exhaustion. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：把相关耐力条件强制为真并持续走最大耐力写回，目标是让奔跑、蓄力、翻滚、格挡和水下动作不再因耐力耗尽而中断。边界：这是两条底层路径的组合，不等同于单纯“耐力消耗减半”；饥饿导致的上限变化和未映射动作仍需确认。验证：分别持续奔跑、连续回避、持盾格挡和进行水下耗耐动作，观察耐力条与动作中断。来源/状态：由 3DS 静态 ARM #37 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces the relevant stamina condition true and keeps taking the maximum-stamina writeback, aiming to prevent sprinting, charging, repeated evasion, guarding, and underwater actions from stopping due to exhaustion. Scope: this combines two low-level paths rather than merely halving drain; hunger-driven maximum changes and unmapped actions still need coverage. Verify: separately sustain sprinting, repeated evasion, shield guarding, and an underwater stamina action while watching the gauge and interruption behavior. Source/status: converted from 3DS static ARM cheat #37; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-39-combination-success-100` — 调和成功率 100% / Combination Success 100%

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/05-balance-breaking/static-39-combination-success-100/manifest.json`
- **Summary / 摘要:** 中文：把可调和配方的成功判定强制为成功，使原本低成功率配方达到 100% 成功。 状态：Runtime Experimental，默认关闭。 / English: Forces valid combination attempts to succeed, turning recipes with a lower base rate into 100% success. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：把可调和配方的成功判定强制为成功，使原本低成功率配方达到 100% 成功。边界：不改变一次调和产量，那属于 #40；仍会正常消耗材料，也不会解锁不存在或条件不足的配方。验证：不携带调和书，连续调和一项基础成功率明显低于 100% 的配方并确认零失败。来源/状态：由 3DS 静态 ARM #39 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces valid combination attempts to succeed, turning recipes with a lower base rate into 100% success. Scope: it does not change output quantity—that is #40—still consumes ingredients normally, and does not unlock nonexistent or unmet recipes. Verify: carry no combo books and repeatedly combine a recipe whose base success rate is clearly below 100%, confirming zero failures. Source/status: converted from 3DS static ARM cheat #39; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-40-maximum-combination-yield` — 最大调和数 / Maximum Combination Yield

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/05-balance-breaking/static-40-maximum-combination-yield/manifest.json`
- **Summary / 摘要:** 中文：对产量有随机区间的配方强制取该次调和的最大可能数量，例如弹药类配方总是给出上限产量。 状态：Runtime Experimental，默认关闭。 / English: Forces recipes with a variable output range to produce their maximum possible quantity, such as the upper ammo yield on every successful combination. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：对产量有随机区间的配方强制取该次调和的最大可能数量，例如弹药类配方总是给出上限产量。边界：不会提高调和成功率，那属于 #39；固定产量配方看不出差异，也不会减少材料消耗。验证：选择明确具有可变产量的弹药或消耗品配方，逐次记录启用前后产量。来源/状态：由 3DS 静态 ARM #40 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces recipes with a variable output range to produce their maximum possible quantity, such as the upper ammo yield on every successful combination. Scope: it does not improve success rate—that is #39—fixed-yield recipes show no difference, and ingredients are still consumed. Verify: use a recipe with a documented variable yield and record each output amount with the pack off and on. Source/status: converted from 3DS static ARM cheat #40; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-65-combat-experience-enhancer` — 战斗体验改善器 / Combat Experience Enhancer

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/05-balance-breaking/static-65-combat-experience-enhancer/manifest.json`
- **Summary / 摘要:** 中文：把常规游戏模式的通用技能槽首次比较强制为命中，目标是一次性激活广泛战斗增益；测试预期包括自动增加攻击、防御、武器属性，以及对风压、地震、吼叫等常见干扰的抗性。 状态：Runtime Experimental，默认关闭。 / English: Forces the first generic skill-slot comparison to match in normal game mode, aiming to activate a broad bundle of combat benefits; expected observations include higher attack, defense, weapon element/status, and resistance to common roar, wind, and tremor disruption. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：把常规游戏模式的通用技能槽首次比较强制为命中，目标是一次性激活广泛战斗增益；测试预期包括自动增加攻击、防御、武器属性，以及对风压、地震、吼叫等常见干扰的抗性。边界：这是高风险广域查询劫持，并非一份精确技能清单；它可能误开无关技能、改变菜单/任务行为并掩盖其他静态 Pack，特殊模式分支保持原样。验证：只启用本项，依次记录面板攻击/防御/属性，再分别测试吼叫、风压、地震和至少一种未预期技能。来源/状态：由 3DS 静态 ARM #65 精确转换；默认关闭；Runtime Experimental，必须隔离实测。 / English: Effect: forces the first generic skill-slot comparison to match in normal game mode, aiming to activate a broad bundle of combat benefits; expected observations include higher attack, defense, weapon element/status, and resistance to common roar, wind, and tremor disruption. Scope: this is a high-risk broad query hijack, not a precise skill list; it may enable unrelated skills, alter menu/quest behavior, and mask other static packs, while the special-mode branch remains native. Verify: enable only this pack, record attack/defense/element first, then separately test roar, wind, tremor, and at least one unintended skill. Source/status: exact conversion of 3DS static ARM cheat #65; Disabled by default; Runtime Experimental and requires isolated gameplay verification.

## `06-quality-of-life` — 便利功能 / Quality of Life

不以改变战斗规则为主的信息显示与导航便利功能。 / Information and navigation conveniences that do not primarily alter combat rules.

Pack count / 插件数: **3** (available / 可用: 3; runtime-blocked / 运行时阻塞: 0).

### `mh3g-hd-jp-v96-static-54-map-always-visible` — 地图常显 / Map Always Visible

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/06-quality-of-life/static-54-map-always-visible/manifest.json`
- **Summary / 摘要:** 中文：强制地图显示条件成立，即使没有领取或携带地图道具，也能看到任务区域地图。 状态：Runtime Experimental，默认关闭。 / English: Forces the map-display condition true so the quest-area map remains visible without collecting or carrying the Map item. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制地图显示条件成立，即使没有领取或携带地图道具，也能看到任务区域地图。边界：只显示地图地形，不自动显示大型怪物位置、捕获时机或全部小怪图标；这些分别属于 #55/#56 等标记功能。验证：进入没有领取地图道具的任务，确认区域编号和连接仍完整显示。来源/状态：由 3DS 静态 ARM #54 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces the map-display condition true so the quest-area map remains visible without collecting or carrying the Map item. Scope: it shows terrain only and does not automatically reveal large-monster locations, capture timing, or every small-monster icon; those belong to marker packs such as #55/#56. Verify: enter a quest without taking the Map item and confirm area numbers and connections remain visible. Source/status: converted from 3DS static ARM cheat #54; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-55-capture-guru` — 观察眼 / Capture Guru

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/06-quality-of-life/static-55-capture-guru/manifest.json`
- **Summary / 摘要:** 中文：强制发动观察眼/Capture Guru；已被标记的大型怪物达到可捕获血量时，地图图标会闪烁提示。 状态：Runtime Experimental，默认关闭。 / English: Forces Capture Guru; once a marked large monster reaches capturable health, its map icon should blink. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制发动观察眼/Capture Guru；已被标记的大型怪物达到可捕获血量时，地图图标会闪烁提示。边界：不会自动标记怪物、显示精确 HP、放置陷阱或自动捕获；没有染色标记时通常看不到提示，除非另有自动标记效果。验证：先给目标怪物染色，再把它打到可捕获状态，观察地图图标是否开始闪烁。来源/状态：由 3DS 静态 ARM #55 转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces Capture Guru; once a marked large monster reaches capturable health, its map icon should blink. Scope: it does not auto-mark the monster, show exact HP, place a trap, or capture automatically; without a paint mark the cue is normally unavailable unless another auto-marker effect is active. Verify: paint the target first, reduce it to capturable health, and watch whether the map icon starts blinking. Source/status: converted from 3DS static ARM cheat #55; Disabled by default; Runtime Experimental and requires gameplay verification.

### `mh3g-hd-jp-v96-static-56-auto-marker-small-monsters` — 自动标记并标记当前区小怪 / Auto-Marker plus Current-Area Small Monsters

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/06-quality-of-life/static-56-auto-marker-small-monsters/manifest.json`
- **Summary / 摘要:** 中文：强制自动标记核心检查，无需染色球即可持续显示大型怪物位置/状态，并尝试把当前区域的小型怪物加入地图标记。 状态：Runtime Experimental，默认关闭。 / English: Forces the core auto-marker checks, continuously showing large-monster position/status without Paintballs and attempting to add current-area small monsters to the map. Status: Runtime Experimental; disabled by default.

**Full description / 完整说明**

中文：效果：强制自动标记核心检查，无需染色球即可持续显示大型怪物位置/状态，并尝试把当前区域的小型怪物加入地图标记。边界：3DS 源中的一个 UI 虚调用点在 PPC 没有一对一静态对应，因此小怪图标覆盖可能不完整；不会显示精确 HP 或自动提供 #55 捕获判断。验证：不使用染色球跨区追踪大型怪物，并在有多种小怪的区域逐一核对地图图标。来源/状态：由 3DS 静态 ARM #56 部分语义转换；默认关闭；Runtime Experimental，需实机验证。 / English: Effect: forces the core auto-marker checks, continuously showing large-monster position/status without Paintballs and attempting to add current-area small monsters to the map. Scope: one 3DS UI virtual-call site has no one-to-one static PPC equivalent, so small-monster icon coverage may be incomplete; it does not show exact HP or automatically provide #55 capture judgment. Verify: track a large monster across areas without painting it, then compare map icons against every small-monster species in a populated area. Source/status: partial semantic conversion of 3DS static ARM cheat #56; Disabled by default; Runtime Experimental and requires gameplay verification.

## `07-item-box-and-interface` — 道具箱与界面 / Item Box and Interface

道具箱界面，以及作为失败证据保留的任务箱运行时阻塞包。 / Item-box interfaces plus retained runtime-blocked task-box research packs.

Pack count / 插件数: **4** (available / 可用: 1; runtime-blocked / 运行时阻塞: 3).

### `mh3g-hd-jp-v96-lobby-full-item-box` — MH3G HD JP v96 - Lobby Full Item Box

- **Status / 状态:** Runtime Verified
- **Availability / 可用性:** available
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/07-item-box-and-interface/lobby-full-item-box/manifest.json`
- **Summary / 摘要:** 中文：把酒场/港口大厅箱子调用完整仓库初始化器时的模式参数由受限模式 `r5 = 1` 改为完整模式 `r5 = 0`，从该大厅箱子打开家中完整道具箱菜单；换装、装备组合、护石及完整菜单交互已经由用户实测通过。 状态：Runtime Verified，默认关闭。 / English: Changes the mode passed by the Port Tanzia/lobby box to the shared full-item-box initializer from restricted `r5 = 1` to full `r5 = 0`, opening the complete home item-box menu from that lobby box; the user gameplay-verified equipment change, equipment sets, talismans, and the complete menu interaction. Status: Runtime Verified; disabled by default.

**Full description / 完整说明**

中文：效果：把酒场/港口大厅箱子调用完整仓库初始化器时的模式参数由受限模式 `r5 = 1` 改为完整模式 `r5 = 0`，从该大厅箱子打开家中完整道具箱菜单；换装、装备组合、护石及完整菜单交互已经由用户实测通过。边界：只修改酒场/港口大厅这一处交互，不替换箱子对象，不影响任务内红色交纳箱或蓝色补给箱，也不生成物品、不改存档和 MLC；关闭后恢复原生受限菜单。验证：只启用本项并从大厅箱子依次打开道具管理、装备变更、装备组合与护石相关页面，完成一次实际切换后退出并重新打开，确认菜单、角色状态和存档读取均正常。来源/状态：JP v96 原生 PPC 单点补丁 `0x02799678: li r5,0`，共享初始化函数保持原样；默认关闭；Runtime Verified / Gameplay Passed。 / English: Effect: changes the mode passed by the Port Tanzia/lobby box to the shared full-item-box initializer from restricted `r5 = 1` to full `r5 = 0`, opening the complete home item-box menu from that lobby box; the user gameplay-verified equipment change, equipment sets, talismans, and the complete menu interaction. Scope: it changes only this lobby interaction, redirects no box object, does not affect the red delivery or blue supply boxes inside quests, and creates no item or save/MLC mutation; disabling it restores the native restricted menu. Verify: enable only this pack and use the lobby box to open item management, equipment change, equipment sets, and talisman-related pages, perform one real change, exit, and reopen the box to confirm the menu, hunter state, and save reading remain normal. Source/status: one native JP-v96 PPC write at `0x02799678: li r5,0`, leaving the shared initializer untouched; Disabled by default; Runtime Verified / Gameplay Passed.

### `mh3g-hd-jp-v96-quest-blue-supply-box-full-item-box-control` — MH3G HD JP v96 - Quest Blue Supply Box - Full Item Box (Control)

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** runtime-blocked
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/07-item-box-and-interface/quest-blue-supply-box-full-item-box-control/manifest.json`
- **Summary / 摘要:** 中文：该研究对照曾尝试移除任务场景的提前退出，并让原生蓝色补给箱以完整模式调用大厅仓库初始化与分发链，目标是从任务蓝箱打开完整家中道具箱。 状态：Runtime Experimental / runtime-blocked，不可安装。 / English: This research control attempted to remove the quest-scene early exit and make the native blue supply box invoke the lobby item-box initializer and dispatcher in full mode, aiming to open the complete home item box from a quest blue box. Status: Runtime Experimental / runtime-blocked; not installable.

**Full description / 完整说明**

中文：效果：该研究对照曾尝试移除任务场景的提前退出，并让原生蓝色补给箱以完整模式调用大厅仓库初始化与分发链，目标是从任务蓝箱打开完整家中道具箱。边界：运行时已证明补丁能够热加载，但与蓝箱交互仍不打开完整仓库，并会把不兼容的任务 UI 状态送入大厅分发器，导致任务看板对话框空白；它不修改红箱，且现为 `runtime-blocked`，安装器不会选择。验证：当前只保留负向证据，不应作为功能包复测；若未来重新立项，必须在隔离单人任务中同时证明蓝箱菜单可打开、任务看板文字正常、输入不锁死并能安全退出任务。来源/状态：JP v96 蓝箱调度桥与 `0x02219DF0 = nop` 对照实验，已被真实交互否定；默认关闭；Runtime Experimental / runtime-blocked，仅作失败研究存档。 / English: Effect: this research control attempted to remove the quest-scene early exit and make the native blue supply box invoke the lobby item-box initializer and dispatcher in full mode, aiming to open the complete home item box from a quest blue box. Scope: runtime evidence proved the patch could hot-load, but interaction still opened no full item box and exposed incompatible quest UI states to the lobby dispatcher, blanking quest-board dialogue; it does not modify the red box and is now `runtime-blocked`, so the installer cannot select it. Verify: retain this only as negative evidence rather than a functional retest pack; any future reopening must prove in an isolated single-player quest that the blue menu opens, quest-board text remains normal, input never locks, and the quest can be exited safely. Source/status: JP-v96 blue-box dispatch-bridge control including `0x02219DF0 = nop`, rejected by real interaction; Disabled by default; Runtime Experimental / runtime-blocked and archived only as failed research.

### `mh3g-hd-jp-v96-quest-delivery-full-item-box-experimental` — MH3G HD JP v96 - Quest Red Delivery Box - Full Item Box (Experimental)

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** runtime-blocked
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/07-item-box-and-interface/quest-delivery-full-item-box-experimental/manifest.json`
- **Summary / 摘要:** 中文：该研究候选曾把红色交纳箱提示/交互选择器改成可用状态，并尝试以完整模式调用大厅仓库初始化器，目标是只从任务红箱打开完整家中道具箱。 状态：Runtime Experimental / runtime-blocked，不可安装。 / English: This research candidate changed the red delivery-box prompt/interaction selector to a usable state and attempted a full-mode call into the lobby item-box initializer, aiming to open the complete home item box from the quest red box only. Status: Runtime Experimental / runtime-blocked; not installable.

**Full description / 完整说明**

中文：效果：该研究候选曾把红色交纳箱提示/交互选择器改成可用状态，并尝试以完整模式调用大厅仓库初始化器，目标是只从任务红箱打开完整家中道具箱。边界：真实任务中红箱仍持续显示不可用红叉或无法弹出菜单；以原生可交互蓝箱做对照也无法启动大厅专属完整仓库生命周期，说明问题不是只缺一个箱子编号或模式参数。本项现为 `runtime-blocked`，不会安装，也不会改变蓝箱。验证：当前只保留负向静态与运行时证据；若未来重新立项，必须先闭环任务场景自身的 UI 对象、状态分发与析构生命周期，再验证红箱可交互、菜单完整、输入恢复和任务结算正常。来源/状态：JP v96 红箱提示、选择器与完整模式初始化的窄范围实验，已被多次真实交互否定；默认关闭；Runtime Experimental / runtime-blocked，仅作失败研究存档。 / English: Effect: this research candidate changed the red delivery-box prompt/interaction selector to a usable state and attempted a full-mode call into the lobby item-box initializer, aiming to open the complete home item box from the quest red box only. Scope: in real quests the red box continued to show an unusable cross or opened no menu; using the natively interactive blue box as a control also failed to start the lobby-only full-item-box lifecycle, proving that a box ID or mode argument alone is insufficient. It is now `runtime-blocked`, cannot be installed, and does not change the blue box. Verify: retain only the negative static/runtime evidence; any future reopening must first close the quest scene's own UI-object, state-dispatch, and destruction lifecycle, then prove red-box interaction, complete menus, restored input, and normal quest settlement. Source/status: narrow JP-v96 experiment covering red-box prompt, selector, and full-mode initialization, rejected by repeated real interaction; Disabled by default; Runtime Experimental / runtime-blocked and archived only as failed research.

### `mh3g-hd-jp-v96-quest-red-blue-full-item-box-experimental` — MH3G HD JP v96 - Quest Red & Blue Boxes - Full Item Box (Experimental)

- **Status / 状态:** Runtime Experimental
- **Availability / 可用性:** runtime-blocked
- **Default install / 默认安装:** false
- **Manifest:** `packs/wiiu/mh3g-hd/jp-v96/07-item-box-and-interface/quest-red-blue-full-item-box-experimental/manifest.json`
- **Summary / 摘要:** 中文：该最终研究候选曾让所有任务中的红箱与蓝箱复用大厅 GUI 对象和资源，并在交互当帧一次性初始化、消费 `0x20` 状态转换及补齐任务场景缺失的最终 UI 挂接，目标是让两类任务箱都打开完整家中道具箱。 状态：Runtime Experimental / runtime-blocked，不可安装。 / English: This final research candidate made both red and blue boxes in every quest reuse lobby GUI objects/resources, then initialized once on the interaction frame, consumed the `0x20` state transition, and completed the final UI attachment missing from quest scenes, aiming to open the complete home item box from either quest box. Status: Runtime Experimental / runtime-blocked; not installable.

**Full description / 完整说明**

中文：效果：该最终研究候选曾让所有任务中的红箱与蓝箱复用大厅 GUI 对象和资源，并在交互当帧一次性初始化、消费 `0x20` 状态转换及补齐任务场景缺失的最终 UI 挂接，目标是让两类任务箱都打开完整家中道具箱。边界：多轮实测出现过进任务崩溃、蓝箱交互无反应或锁住收刀/攻击切换、红箱仍显示不可用等结果，始终没有形成可复现且安全的任务 UI 生命周期；因此它不是可用功能包，现为 `runtime-blocked`，安装器不会选择。验证：当前只保留补丁边界和失败记录；若未来重新立项，必须逐阶段证明任务载入、两箱提示、菜单创建、输入恢复、退出菜单、任务结算和连续第二场任务均无异常，任何一步失败都不得解除阻断。来源/状态：JP v96 任务本地一次性激活、状态消费、UI 工厂/资源复用的综合 PPC 实验，已由真实崩溃与无响应结果否定；默认关闭；Runtime Experimental / runtime-blocked，仅作失败研究存档。 / English: Effect: this final research candidate made both red and blue boxes in every quest reuse lobby GUI objects/resources, then initialized once on the interaction frame, consumed the `0x20` state transition, and completed the final UI attachment missing from quest scenes, aiming to open the complete home item box from either quest box. Scope: repeated gameplay produced quest-entry crashes, blue-box no-op or locked sheathe/attack switching, and a still-unusable red prompt, never yielding a reproducible safe quest UI lifecycle; it is therefore not a functional pack, is `runtime-blocked`, and cannot be selected by the installer. Verify: retain only its patch boundaries and failure record; any future reopening must separately pass quest loading, both prompts, menu construction, input recovery, menu exit, quest settlement, and a second consecutive quest, with any failure keeping the block in place. Source/status: combined JP-v96 PPC experiment for task-local one-shot activation, state consumption, and UI-factory/resource reuse, rejected by real crash and no-response results; Disabled by default; Runtime Experimental / runtime-blocked and archived only as failed research.
